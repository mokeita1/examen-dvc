Nom : Mohamed Lamine KEITA  
Adresse mail : mohamed.keita@me.com 
Dépôt DagsHub : https://dagshub.com/mokeita1/examen-dvc